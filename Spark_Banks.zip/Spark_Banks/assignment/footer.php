
    <footer class="white-section" id="footer">
      <a href="https://twitter.com/tsfsingapore" class="fab fa-twitter f-button" target="_blank"></a>
       <a href="https://www.facebook.com/thesparksfoundation.info" class="fab fa-facebook-f f-button" target="_blank"></a>
      <a href="https://www.instagram.com/thesparksfoundation.info/" class="fab fa-instagram f-button" target="_blank"></a>
       <a href="https://www.linkedin.com/company/the-sparks-foundation/" class="fab fa-linkedin f-button" target="_blank"></a>

      <p>� Copyright 2021 Sparks Foundation</p>

    </footer>